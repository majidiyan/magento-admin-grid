<?php
/*class Pfay_Majidian_Adminhtml_IndexController extends Mage_Adminhtml_Controller_Action { 
  public function indexAction()   { 
            $this->loadLayout();         
			  $this->renderLayout();  
			   } 
			   }*/
			   
			   
			   
class Pfay_Majidian_Adminhtml_IndexController extends Mage_Adminhtml_Controller_Action {     
protected function _initAction()     {         
$this->loadLayout()->_setActiveMenu('majidian/set_time')->_addBreadcrumb('majidian Manager','majidian Manager');        
return $this;      
}       

public function indexAction()       {          
$this->_initAction();          
$this->renderLayout();       
}       

public function editAction()       {            
$majidianId = $this->getRequest()->getParam('id');            
$majidianModel = Mage::getModel('majidian/majidian')->load($majidianId);            
if ($majidianModel->getId() || $majidianId == 0) {              
Mage::register('majidian_data', $majidianModel);              
$this->loadLayout();              
$this->_setActiveMenu('majidian/set_time');              
$this->_addBreadcrumb('majidian Manager', 'majidian Manager');              
$this->_addBreadcrumb('Majidian Description', 'Majidian Description');             
$this->getLayout()->getBlock('head')->setCanLoadExtJs(true);              
$this->_addContent($this->getLayout()->createBlock('majidian/adminhtml_majidian_edit')) ->_addLeft($this->getLayout()->createBlock('majidian/adminhtml_majidian_edit_tabs') );              
$this->renderLayout();            
}   else { Mage::getSingleton('adminhtml/session') ->addError('Majidian does not exist');                  
$this->_redirect('*/*/');             
}        
}        

public function newAction()        {           
$this->_forward('edit');        
}        

public function saveAction()        {          
if ($this->getRequest()->getPost())          {            
try { $postData = $this->getRequest()->getPost();                  
$majidianModel = Mage::getModel('majidian/majidian');                
if( $this->getRequest()->getParam('id') <= 0 )                   
$majidianModel->setCreatedTime( Mage::getSingleton('core/date') ->gmtDate() );                   
$majidianModel ->addData($postData)->setUpdateTime(Mage::getSingleton('core/date')->gmtDate())->setId($this->getRequest()->getParam('id'))  ->save();                  
Mage::getSingleton('adminhtml/session') ->addSuccess('successfully saved');                  
Mage::getSingleton('adminhtml/session') ->setmajidianData(false);                  
$this->_redirect('*/*/');                
 return;           } 
 
 catch (Exception $e){                 
 Mage::getSingleton('adminhtml/session')->addError($e->getMessage());                 
 Mage::getSingleton('adminhtml/session')->setmajidianData($this->getRequest()->getPost()                 ); 
 $this->_redirect('*/*/edit',array('id' => $this->getRequest()->getParam('id')));                 
 return;                 
 }               
 }               
 $this->_redirect('*/*/');             
 }           
 
 public function deleteAction()           {              
  if($this->getRequest()->getParam('id') > 0)  {                 
  try {                     
  $majidianModel = Mage::getModel('majidian/majidian');                     
  $majidianModel->setId($this->getRequest()->getParam('id'))->delete();
  Mage::getSingleton('adminhtml/session')->addSuccess('successfully deleted');                     
  $this->_redirect('*/*/');                  
  }                  
  
  catch (Exception $e)  {                            
  Mage::getSingleton('adminhtml/session')->addError($e->getMessage());                            
  $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));                   
  }              
  }             
  $this->_redirect('*/*/');        
  } 
  } 
?>