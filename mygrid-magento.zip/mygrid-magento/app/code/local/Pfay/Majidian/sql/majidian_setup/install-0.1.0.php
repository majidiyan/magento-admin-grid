<?php
    $installer=$this;
	$installer->startSetup();
	/*
	 * Creates pfay_mypostexpress Table
	 */
	$table=$installer->getConnection()
	->newTable($installer->getTable('majidian/majidian'))
	->addColumn('id_pfay_majidian', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'identity'  => true,
        'unsigned'  => true,
        'nullable'  => false,
        'primary'   => true,
        ), 'Tier Id')
	->addColumn('nom', Varien_Db_Ddl_Table::TYPE_VARCHAR, 50, array(
    
    'nullable'  => false,
    ), 'Tier Maximum Applicable Weight')
	->addColumn('prenom', Varien_Db_Ddl_Table::TYPE_VARCHAR, 50, array(
   
    'nullable'  => false,
    ), 'Fee Charged For Transportaion within the city')
	->addColumn('telephone', Varien_Db_Ddl_Table::TYPE_VARCHAR, 20, array(
    
    'nullable'  => false,
    ), 'Fee Charged For Transportaion Within Province');
        
        $installer->getConnection()->createTable($table);
        
	$installer->endSetup();
