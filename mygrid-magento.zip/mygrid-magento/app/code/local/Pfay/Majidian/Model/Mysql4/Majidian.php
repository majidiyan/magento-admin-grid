<?php
class Pfay_Majidian_Model_Mysql4_Majidian extends Mage_Core_Model_Mysql4_Abstract {
      public function _construct()      {      
	      $this->_init('majidian/majidian', 'id_pfay_majidian');    
		    } 
			}
?>