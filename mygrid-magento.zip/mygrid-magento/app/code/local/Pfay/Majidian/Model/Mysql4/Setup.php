<?php
    class Pfay_Majidian_Model_Mysql4_Setup extends Mage_Core_Model_Resource_Setup{
    	
    }
?>